import '@wikimedia/types-wikimedia';
