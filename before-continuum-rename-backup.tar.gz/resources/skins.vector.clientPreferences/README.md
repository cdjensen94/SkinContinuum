This code is designed to work across any skin.

To publish a new version.
```
npm publish  --access public
```
