/** For virtual configuration of resources/skins.vector.js/config.json */
interface VectorResourceLoaderVirtualConfig {
	VectorSearchApiUrl: string;
}
