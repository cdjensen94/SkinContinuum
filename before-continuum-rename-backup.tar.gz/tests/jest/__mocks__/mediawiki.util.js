module.exports = {
	debounce: ( /** @type {Function} */fn ) => fn
};
