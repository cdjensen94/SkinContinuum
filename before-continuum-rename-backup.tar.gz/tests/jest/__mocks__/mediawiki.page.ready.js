module.exports = {
	checkboxHack: () => {}
};
